# gearboxscott.general roles

- role_git - This role can be used to do a git pull and git push within a playbook.