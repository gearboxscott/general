======================================
Reyes Compute Collection Release Notes
======================================

.. contents:: Topics

Release Summary
---------------

v1.0.2
======

Minor Changes
-------------

- Fixing Documentation

Bugfixes
--------

- None

New Modules
-----------

- None

v1.0.1
======

Minor Changes
-------------

- Fixing Documentation

Bugfixes
--------

- None

New Modules
-----------

- None

v1.0.0
======

Minor Changes
-------------

- None

Bugfixes
--------

- None

New Modules
-----------

- role_git
